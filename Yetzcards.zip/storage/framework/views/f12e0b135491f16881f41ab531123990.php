<!-- resources/views/layouts/app.blade.php -->

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Adicione aqui seus estilos CSS, scripts JS, etc. -->
</head>
<body>
    <header>
        <!-- Aqui vai o cabeçalho comum -->
        <h1><?php echo e(config('app.name', 'Laravel')); ?></h1>
    </header>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer>
        <!-- Aqui vai o rodapé comum -->
        <p>&copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name', 'Laravel')); ?></p>
    </footer>
</body>
</html><?php /**PATH C:\Yetzcards\resources\views/layouts/app.blade.php ENDPATH**/ ?>